.. cmake-module:: ../../Modules/TestCXXAcceptsFlag.cmake
