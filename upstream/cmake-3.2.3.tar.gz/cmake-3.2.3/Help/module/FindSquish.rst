.. cmake-module:: ../../Modules/FindSquish.cmake
