.. cmake-module:: ../../Modules/CPackPackageMaker.cmake
