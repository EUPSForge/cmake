ctest_upload
------------

Upload files to a dashboard server.

::

  ctest_upload(FILES ...)

Pass a list of files to be sent along with the build results to the
dashboard server.
