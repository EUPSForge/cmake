RULE_LAUNCH_CUSTOM
------------------

Specify a launcher for custom rules.

See the global property of the same name for details.  This overrides
the global property for a directory.
